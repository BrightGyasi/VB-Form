﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        MessageCheckBox = New CheckBox()
        BackgroundGroupBox = New GroupBox()
        GreenRadioButton = New RadioButton()
        BlueRadioButton = New RadioButton()
        RedRadioButton = New RadioButton()
        GrayRadioButton = New RadioButton()
        StudentInformationGroupBox = New GroupBox()
        PhoneMaskedTextBox = New MaskedTextBox()
        TextBox5 = New TextBox()
        PhoneLabel = New Label()
        MajorTextBox = New TextBox()
        MajorLabel = New Label()
        NameTextBox = New TextBox()
        NameLabel = New Label()
        OutputLabel = New Label()
        TextGroupBox = New GroupBox()
        WhiteRadioButton = New RadioButton()
        BlackRadioButton = New RadioButton()
        OutputTextBox = New TextBox()
        SnowPictureBox = New PictureBox()
        SunPictureBox = New PictureBox()
        DisplayButton = New Button()
        ResetyButton = New Button()
        ExitButton = New Button()
        BackgroundGroupBox.SuspendLayout()
        StudentInformationGroupBox.SuspendLayout()
        TextGroupBox.SuspendLayout()
        CType(SnowPictureBox, ComponentModel.ISupportInitialize).BeginInit()
        CType(SunPictureBox, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' MessageCheckBox
        ' 
        resources.ApplyResources(MessageCheckBox, "MessageCheckBox")
        MessageCheckBox.Name = "MessageCheckBox"
        MessageCheckBox.UseVisualStyleBackColor = True
        ' 
        ' BackgroundGroupBox
        ' 
        resources.ApplyResources(BackgroundGroupBox, "BackgroundGroupBox")
        BackgroundGroupBox.Controls.Add(GreenRadioButton)
        BackgroundGroupBox.Controls.Add(BlueRadioButton)
        BackgroundGroupBox.Controls.Add(RedRadioButton)
        BackgroundGroupBox.Controls.Add(GrayRadioButton)
        BackgroundGroupBox.ForeColor = Color.RoyalBlue
        BackgroundGroupBox.Name = "BackgroundGroupBox"
        BackgroundGroupBox.TabStop = False
        ' 
        ' GreenRadioButton
        ' 
        resources.ApplyResources(GreenRadioButton, "GreenRadioButton")
        GreenRadioButton.ForeColor = SystemColors.ControlText
        GreenRadioButton.Name = "GreenRadioButton"
        GreenRadioButton.TabStop = True
        GreenRadioButton.UseVisualStyleBackColor = True
        ' 
        ' BlueRadioButton
        ' 
        resources.ApplyResources(BlueRadioButton, "BlueRadioButton")
        BlueRadioButton.ForeColor = SystemColors.ControlText
        BlueRadioButton.Name = "BlueRadioButton"
        BlueRadioButton.TabStop = True
        BlueRadioButton.UseVisualStyleBackColor = True
        ' 
        ' RedRadioButton
        ' 
        resources.ApplyResources(RedRadioButton, "RedRadioButton")
        RedRadioButton.ForeColor = SystemColors.ControlText
        RedRadioButton.Name = "RedRadioButton"
        RedRadioButton.TabStop = True
        RedRadioButton.UseVisualStyleBackColor = True
        ' 
        ' GrayRadioButton
        ' 
        resources.ApplyResources(GrayRadioButton, "GrayRadioButton")
        GrayRadioButton.ForeColor = SystemColors.ControlText
        GrayRadioButton.Name = "GrayRadioButton"
        GrayRadioButton.TabStop = True
        GrayRadioButton.UseVisualStyleBackColor = True
        ' 
        ' StudentInformationGroupBox
        ' 
        resources.ApplyResources(StudentInformationGroupBox, "StudentInformationGroupBox")
        StudentInformationGroupBox.Controls.Add(PhoneMaskedTextBox)
        StudentInformationGroupBox.Controls.Add(PhoneLabel)
        StudentInformationGroupBox.Controls.Add(MajorTextBox)
        StudentInformationGroupBox.Controls.Add(MajorLabel)
        StudentInformationGroupBox.Controls.Add(NameTextBox)
        StudentInformationGroupBox.Controls.Add(NameLabel)
        StudentInformationGroupBox.ForeColor = Color.RoyalBlue
        StudentInformationGroupBox.Name = "StudentInformationGroupBox"
        StudentInformationGroupBox.TabStop = False
        ' 
        ' PhoneMaskedTextBox
        ' 
        resources.ApplyResources(PhoneMaskedTextBox, "PhoneMaskedTextBox")
        PhoneMaskedTextBox.Name = "PhoneMaskedTextBox"
        ' 
        ' TextBox5
        ' 
        resources.ApplyResources(TextBox5, "TextBox5")
        TextBox5.Name = "TextBox5"
        ' 
        ' PhoneLabel
        ' 
        resources.ApplyResources(PhoneLabel, "PhoneLabel")
        PhoneLabel.ForeColor = SystemColors.ControlText
        PhoneLabel.Name = "PhoneLabel"
        ' 
        ' MajorTextBox
        ' 
        resources.ApplyResources(MajorTextBox, "MajorTextBox")
        MajorTextBox.Name = "MajorTextBox"
        ' 
        ' MajorLabel
        ' 
        resources.ApplyResources(MajorLabel, "MajorLabel")
        MajorLabel.ForeColor = SystemColors.ControlText
        MajorLabel.Name = "MajorLabel"
        ' 
        ' NameTextBox
        ' 
        resources.ApplyResources(NameTextBox, "NameTextBox")
        NameTextBox.Name = "NameTextBox"
        ' 
        ' NameLabel
        ' 
        resources.ApplyResources(NameLabel, "NameLabel")
        NameLabel.ForeColor = SystemColors.ControlText
        NameLabel.Name = "NameLabel"
        ' 
        ' OutputLabel
        ' 
        resources.ApplyResources(OutputLabel, "OutputLabel")
        OutputLabel.ForeColor = SystemColors.ControlText
        OutputLabel.Name = "OutputLabel"
        ' 
        ' TextGroupBox
        ' 
        resources.ApplyResources(TextGroupBox, "TextGroupBox")
        TextGroupBox.Controls.Add(WhiteRadioButton)
        TextGroupBox.Controls.Add(BlackRadioButton)
        TextGroupBox.ForeColor = Color.RoyalBlue
        TextGroupBox.Name = "TextGroupBox"
        TextGroupBox.TabStop = False
        ' 
        ' WhiteRadioButton
        ' 
        resources.ApplyResources(WhiteRadioButton, "WhiteRadioButton")
        WhiteRadioButton.ForeColor = SystemColors.ControlText
        WhiteRadioButton.Name = "WhiteRadioButton"
        WhiteRadioButton.TabStop = True
        WhiteRadioButton.UseVisualStyleBackColor = True
        ' 
        ' BlackRadioButton
        ' 
        resources.ApplyResources(BlackRadioButton, "BlackRadioButton")
        BlackRadioButton.ForeColor = SystemColors.ControlText
        BlackRadioButton.Name = "BlackRadioButton"
        BlackRadioButton.TabStop = True
        BlackRadioButton.UseVisualStyleBackColor = True
        ' 
        ' OutputTextBox
        ' 
        resources.ApplyResources(OutputTextBox, "OutputTextBox")
        OutputTextBox.Name = "OutputTextBox"
        ' 
        ' SnowPictureBox
        ' 
        resources.ApplyResources(SnowPictureBox, "SnowPictureBox")
        SnowPictureBox.Name = "SnowPictureBox"
        SnowPictureBox.TabStop = False
        ' 
        ' SunPictureBox
        ' 
        resources.ApplyResources(SunPictureBox, "SunPictureBox")
        SunPictureBox.Name = "SunPictureBox"
        SunPictureBox.TabStop = False
        ' 
        ' DisplayButton
        ' 
        resources.ApplyResources(DisplayButton, "DisplayButton")
        DisplayButton.BackColor = Color.Cyan
        DisplayButton.Name = "DisplayButton"
        DisplayButton.UseVisualStyleBackColor = False
        ' 
        ' ResetyButton
        ' 
        resources.ApplyResources(ResetyButton, "ResetyButton")
        ResetyButton.BackColor = Color.Cyan
        ResetyButton.Name = "ResetyButton"
        ResetyButton.UseVisualStyleBackColor = False
        ' 
        ' ExitButton
        ' 
        resources.ApplyResources(ExitButton, "ExitButton")
        ExitButton.BackColor = Color.Cyan
        ExitButton.Name = "ExitButton"
        ExitButton.UseVisualStyleBackColor = False
        ' 
        ' Form1
        ' 
        resources.ApplyResources(Me, "$this")
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.Control
        Controls.Add(ExitButton)
        Controls.Add(TextBox5)
        Controls.Add(ResetyButton)
        Controls.Add(OutputLabel)
        Controls.Add(DisplayButton)
        Controls.Add(SunPictureBox)
        Controls.Add(SnowPictureBox)
        Controls.Add(OutputTextBox)
        Controls.Add(TextGroupBox)
        Controls.Add(BackgroundGroupBox)
        Controls.Add(MessageCheckBox)
        Controls.Add(StudentInformationGroupBox)
        Name = "Form1"
        BackgroundGroupBox.ResumeLayout(False)
        BackgroundGroupBox.PerformLayout()
        StudentInformationGroupBox.ResumeLayout(False)
        StudentInformationGroupBox.PerformLayout()
        TextGroupBox.ResumeLayout(False)
        TextGroupBox.PerformLayout()
        CType(SnowPictureBox, ComponentModel.ISupportInitialize).EndInit()
        CType(SunPictureBox, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents MessageCheckBox As CheckBox
    Friend WithEvents BackgroundGroupBox As GroupBox
    Friend WithEvents StudentInformationGroupBox As GroupBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents OutputLabel As Label
    Friend WithEvents PhoneLabel As Label
    Friend WithEvents MajorTextBox As TextBox
    Friend WithEvents MajorLabel As Label
    Friend WithEvents NameTextBox As TextBox
    Friend WithEvents NameLabel As Label
    Friend WithEvents GreenRadioButton As RadioButton
    Friend WithEvents BlueRadioButton As RadioButton
    Friend WithEvents RedRadioButton As RadioButton
    Friend WithEvents GrayRadioButton As RadioButton
    Friend WithEvents TextGroupBox As GroupBox
    Friend WithEvents WhiteRadioButton As RadioButton
    Friend WithEvents BlackRadioButton As RadioButton
    Friend WithEvents PhoneMaskedTextBox As MaskedTextBox
    Friend WithEvents OutputTextBox As TextBox
    Friend WithEvents SnowPictureBox As PictureBox
    Friend WithEvents SunPictureBox As PictureBox
    Friend WithEvents DisplayButton As Button
    Friend WithEvents ResetyButton As Button
    Friend WithEvents ExitButton As Button

End Class
