﻿Public Class Form1
    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles PhoneLabel.Click

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles MajorLabel.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles OutputTextBox.TextChanged

    End Sub

    Private Sub RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles WhiteRadioButton.CheckedChanged

    End Sub

    Private Sub MessageCheckBox_CheckedChanged(sender As Object, e As EventArgs) Handles MessageCheckBox.CheckedChanged

    End Sub

    Private Sub OutputLabel_Click(sender As Object, e As EventArgs) Handles OutputLabel.Click

    End Sub
End Class
